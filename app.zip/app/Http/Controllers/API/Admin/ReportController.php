<?php

namespace App\Http\Controllers\API\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
use App\Models\User;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Job;
use App\Models\Contest;
use App\Models\ProductsServicesBook;

class ReportController extends Controller
{
    public function index()
    {
    }
}
